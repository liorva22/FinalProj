/**
 * 
 */
package org.bgu.ise.ddb.registration;

import com.mongodb.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.ParentController;
import org.bgu.ise.ddb.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author Alex
 *
 */


@RestController
@RequestMapping(value = "/registration")
public class RegistarationController extends ParentController {

	/**
	 * The function checks if the username exist, in case of positive answer
	 * HttpStatus in HttpServletResponse should be set to HttpStatus.CONFLICT, else
	 * insert the user to the system and set to HttpStatus in HttpServletResponse
	 * HttpStatus.OK
	 * 
	 * @param username
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param response
	 */
	@RequestMapping(value = "register_new_customer", method = { RequestMethod.POST })
	public void registerNewUser(@RequestParam("username") String username, @RequestParam("password") String password,
			@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			HttpServletResponse response) {
		System.out.println(username + " " + password + " " + lastName + " " + firstName);
		MongoClient mongoClient = null;
		try {
			// Check if the user name already exists
			if (isExistUser(username)) {
				HttpStatus status = HttpStatus.CONFLICT;
				response.setStatus(status.value());
			} else {
				// Create a new User object
				User newUser = new User(username, password, firstName, lastName);

				// Connect to MongoDB
				 mongoClient = new MongoClient("localhost", 27017);
				DB db = mongoClient.getDB("FinalProjBigData");

				// Access the "users" collection
				DBCollection users = db.getCollection("Users");

				// Create a BasicDBObject to represent the new user
				BasicDBObject newUserObj = new BasicDBObject();
				newUserObj.put("username", newUser.getUsername());
				newUserObj.put("password", newUser.getPassword());
				newUserObj.put("firstName", newUser.getFirstName());
				newUserObj.put("lastName", newUser.getLastName());
				LocalDate dateObj =LocalDate.now(); 
				DateTimeFormatter formater = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String date1 = dateObj.format(formater);
	            newUserObj.put("registrationDate", date1); // Add the registration date with the current timestamp

				// Insert the new user into the collection
				users.insert(newUserObj);

				// Close the MongoDB connection
				mongoClient.close();

				HttpStatus status = HttpStatus.OK;
				response.setStatus(status.value());
			}
		} catch (IOException e) {
			e.printStackTrace();
			HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
			response.setStatus(status.value());
		}finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}
	}

	/**
	 * The function returns true if the received username exist in the system
	 * otherwise false
	 * 
	 * @param username
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "is_exist_user", method = { RequestMethod.GET })
	public boolean isExistUser(@RequestParam("username") String username) throws IOException {
		System.out.println(username);
		MongoClient mongoClient = null;

		boolean result = false;
		try {
			// Connect to MongoDB
			mongoClient = new MongoClient("localhost", 27017);
			DB db = mongoClient.getDB("FinalProjBigData");

			// Access the "users" collection
			DBCollection users = db.getCollection("Users");

			// Create the query
			BasicDBObject query = new BasicDBObject();
			query.put("username", username);

			// Execute the query
			DBCursor cursor = users.find(query);

			// Check if a matching user was found
			result = cursor.count() != 0;

			// Close the MongoDB connection
			mongoClient.close();
		} catch (MongoException e) {
			e.printStackTrace();
		}finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}
		return result;

	}

	/**
	 * The function returns true if the received username and password match a
	 * system storage entry, otherwise false
	 * 
	 * @param username
	 * @return
	 * @throws IOException
	 */

	@RequestMapping(value = "validate_user", method = { RequestMethod.POST })
	public boolean validateUser(@RequestParam("username") String username, @RequestParam("password") String password)
			throws IOException {
		System.out.println(username + " " + password);
		MongoClient mongoClient = null;

		boolean result = false;
		// :TODO your implementation
		try {
			// connect to MongoDb:
			mongoClient = new MongoClient("localhost", 27017);
			DB db = mongoClient.getDB("FinalProjBigData");

			// Access the "users" collection
			DBCollection users = db.getCollection("Users");

			BasicDBObject myQuery = new BasicDBObject();
			myQuery.put("username", username);
			myQuery.put("password", password);
			DBCursor cursor = users.find(myQuery);

			// check if we find at least one result
			if (cursor.count() != 0) {
				result = true;
			}
			mongoClient.close();
		} catch (MongoException e) {
			e.printStackTrace();

		}finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}
		return result;

	}

	/**
	 * The function retrieves number of the registered users in the past n days
	 * 
	 * @param days
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "get_number_of_registred_users", method = { RequestMethod.GET })
	public int getNumberOfRegistredUsers(@RequestParam("days") int days) throws IOException {
		System.out.println(days + "");
		MongoClient mongoClient = null;

	    int result = 0;
	    try {
	        // Connect to MongoDB
	        mongoClient = new MongoClient("localhost", 27017);
	        DB db = mongoClient.getDB("FinalProjBigData");

	        // Access the "users" collection
	        DBCollection users = db.getCollection("Users");

	        // Get the current date
	        LocalDate currentDate = LocalDate.now();

	        // Calculate the date n days ago
	        LocalDate startDate = currentDate.minusDays(days);

	        // Construct the query to count registered users within the specified date range
	        BasicDBObject query = new BasicDBObject();
	        query.put("registrationDate", new BasicDBObject("$gt", startDate.toString()).append("$lte", currentDate.toString()));

	        // Execute the query and count the number of documents
	        result = users.find(query).count();

	        // Close the MongoDB connection
	        mongoClient.close();
	    } catch (MongoException e) {
	        e.printStackTrace();
	    }finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}

	    return result;
	}

	/**
	 * The function retrieves all the users
	 * 
	 * @return
	 */
	@RequestMapping(value = "get_all_users", headers = "Accept=*/*", method = {
			RequestMethod.GET }, produces = "application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(User.class)
	public User[] getAllUsers() {
	    User[] userList = null;
		MongoClient mongoClient = null;

	    try {
	        // Connect to MongoDB
	        mongoClient = new MongoClient("localhost", 27017);
	        DB db = mongoClient.getDB("FinalProjBigData");

	        // Access the "users" collection
	        DBCollection users = db.getCollection("Users");

	        // Execute the query to retrieve all users
	        DBCursor cursor = users.find();

	        // Initialize the user array with the cursor size
	        userList = new User[cursor.size()];

	        // Iterate over the cursor and populate the user array
	        int i = 0;
	        while (cursor.hasNext()) {
	            DBObject user_obj = cursor.next();
	            String username = (String) user_obj.get("username");
	            String password = (String) user_obj.get("password");
	            String firstName = (String) user_obj.get("firstName");
	            String lastName = (String) user_obj.get("lastName");
	            User user = new User(username, password, firstName, lastName);
	            userList[i] = user;
	            i++;
	        }

	        // Close the MongoDB connection
	        mongoClient.close();
	    } catch (MongoException e) {
	        e.printStackTrace();
	    }finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}
	    return userList;
	}

}
