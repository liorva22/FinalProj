/**
 * 
 */
package org.bgu.ise.ddb.items;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.MediaItems;
import org.bgu.ise.ddb.ParentController;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.mongodb.*;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import java.util.ArrayList;

/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/items")
public class ItemsController extends ParentController {
	
	
	/**
	 * The function copy all the items(title and production year) from the SSMS table MediaItems to the System storage.
	 * The SSMS table and data should be used from the previous assignment
	 */
	@RequestMapping(value = "fill_media_items", method={RequestMethod.GET})
	public void fillMediaItems(HttpServletResponse response){
		MongoClient mongoClient = null;
		Connection connection = null;
        System.out.println("was here");
        // Database connection parameters
        String username = "liorva";
        String password = ")T3OTU^H";
        String connectionUrl = "jdbc:sqlserver://132.72.64.124:1433;databaseName=" + username + ";user=" + username + ";password={" + password + "};encrypt=false;";

        try {
            // Connect to the SSMS database
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(connectionUrl);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute the SQL query to retrieve all items from the MediaItems table
            String query = "SELECT TITLE, PROD_YEAR FROM MediaItems";
            ResultSet resultSet = statement.executeQuery(query);

            // Connect to MongoDB
            mongoClient = new MongoClient("localhost", 27017);
            DB db = mongoClient.getDB("FinalProjBigData");

            // Access the "items" collection
            DBCollection items = db.getCollection("Items");

            // Iterate over the result set and store the items in the MongoDB collection
            while (resultSet.next()) {
                String title = resultSet.getString("TITLE");
                int prodYear = resultSet.getInt("PROD_YEAR");

                // Check if the item already exists in the collection
                BasicDBObject searchQuery = new BasicDBObject();
                searchQuery.put("title", title);
                searchQuery.put("prod_year", prodYear);
                DBCursor cursor = items.find(searchQuery);

                // If the item doesn't exist, insert it into the collection
                if (cursor.count() == 0) {
                    // Create a new document
                    BasicDBObject newItemObj = new BasicDBObject();
                    newItemObj.put("title", title);
                    newItemObj.put("prod_year", prodYear);

                    // Insert the new item into the collection
                    items.insert(newItemObj);
                }
            }

            // Close the result set, statement, and connection
            resultSet.close();
            statement.close();
            connection.close();

            // Close the MongoDB connection
            mongoClient.close();

            HttpStatus status = HttpStatus.OK;
            response.setStatus(status.value());
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
            response.setStatus(status.value());
        } finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    

    /**
     * The function copies all the items from the remote file,
     * the remote file has the same structure as the films file from the previous assignment.
     * You can assume that the address protocol is http.
     * @throws IOException 
     */
    @RequestMapping(value = "fill_media_items_from_url", method={RequestMethod.GET})
    public void fillMediaItemsFromUrl(@RequestParam("url") String urladdress,
                                      HttpServletResponse response) throws IOException {
        System.out.println(urladdress);
		MongoClient mongoClient = null;

        // Create a list to store the MediaItems
        List<MediaItems> mediaItemsList = new ArrayList<>();

        // Read the remote file and store the items
        URL url = new URL(urladdress);
        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length >= 2) {
                String title = parts[0].trim();
                int prodYear = Integer.parseInt(parts[1].trim());
                MediaItems mediaItem = new MediaItems(title, prodYear);
                mediaItemsList.add(mediaItem);
            }
        }
        reader.close();

        // Store the MediaItems in MongoDB collection "Items"
        try {
            mongoClient = new MongoClient("localhost", 27017);
            DB db = mongoClient.getDB("FinalProjBigData");
            DBCollection itemsCollection = db.getCollection("Items");

            for (MediaItems mediaItem : mediaItemsList) {
                // Check if the item already exists in the collection
                BasicDBObject searchQuery = new BasicDBObject();
                searchQuery.put("title", mediaItem.getTitle());
                searchQuery.put("prod_year", mediaItem.getProdYear());
                DBCursor cursor = itemsCollection.find(searchQuery);

                // If the item doesn't exist, insert it into the collection
                if (cursor.count() == 0) {
                    BasicDBObject itemObj = new BasicDBObject();
                    itemObj.put("title", mediaItem.getTitle());
                    itemObj.put("prod_year", mediaItem.getProdYear());
                    itemsCollection.insert(itemObj);
                }
            }

            mongoClient.close();

            HttpStatus status = HttpStatus.OK;
            response.setStatus(status.value());
        } catch (MongoException e) {
            e.printStackTrace();
        }finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}
    } 



	@RequestMapping(value = "get_topn_items",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(MediaItems.class)
	public  MediaItems[] getTopNItems(@RequestParam("topn")    int topN){
	    List<MediaItems> mediaItemsList = new ArrayList<>();
		MongoClient mongoClient = null;

	    try {
	        mongoClient = new MongoClient("localhost", 27017);
	        MongoDatabase db = mongoClient.getDatabase("FinalProjBigData");
	        MongoCollection<Document> collection = db.getCollection("Items");

	        FindIterable<Document> result = collection.find().limit(topN);

	        for (Document document : result) {
	            String title = document.getString("title");
	            int prodYear = document.getInteger("prod_year");
	            MediaItems mediaItem = new MediaItems(title, prodYear);
	            mediaItemsList.add(mediaItem);
	        }

	        mongoClient.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}

	    // Convert list to array before returning
	    return mediaItemsList.toArray(new MediaItems[0]);		
	}

}
