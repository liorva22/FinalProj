/**
 * 
 */
package org.bgu.ise.ddb.history;

import java.util.Collections;
import java.util.Date;
import com.mongodb.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import java.util.HashSet;
import java.util.Set;

import org.bgu.ise.ddb.ParentController;
import org.bgu.ise.ddb.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/history")
public class HistoryController extends ParentController {

	/**
	 * The function inserts to the system storage triple(s)(username, title,
	 * timestamp). The timestamp - in ms since 1970 Advice: better to insert the
	 * history into two structures( tables) in order to extract it fast one with the
	 * key - username, another with the key - title
	 * 
	 * @param username
	 * @param title
	 * @param response
	 */
	@RequestMapping(value = "insert_to_history", method = { RequestMethod.GET })
	public void insertToHistory(@RequestParam("username") String username, @RequestParam("title") String title,
	        HttpServletResponse response) {
	    System.out.println(username + " " + title);
		MongoClient mongoClient = null;

	    try {
	        // Connect to MongoDB
	        mongoClient = new MongoClient("localhost", 27017);
	        DB db = mongoClient.getDB("FinalProjBigData");

	        // Access the "Users" collection and check if the username exists
	        DBCollection userCollection = db.getCollection("Users");
	        BasicDBObject userQuery = new BasicDBObject();
	        userQuery.put("username", username);
	        long userCount = userCollection.count(userQuery);

	        // Access the "Items" collection and check if the title exists
	        DBCollection itemCollection = db.getCollection("Items");
	        BasicDBObject itemQuery = new BasicDBObject();
	        itemQuery.put("title", title);
	        long itemCount = itemCollection.count(itemQuery);

	        if(userCount > 0 && itemCount > 0) {
	            // If both username and title exist, proceed with the history record insertion
	            // Access the "UserHistory" collection
	            DBCollection userHistoryCollection = db.getCollection("UserHistory");

	            // Create a document for the user history record
	            BasicDBObject userDocument = new BasicDBObject();
	            userDocument.put("username", username);
	            userDocument.put("title", title);
	            userDocument.put("timestamp", new Date().getTime());

	            // Insert the user history record
	            userHistoryCollection.insert(userDocument);

	            // Access the "TitleHistory" collection
	            DBCollection titleHistoryCollection = db.getCollection("TitleHistory");

	            // Create a document for the title history record
	            BasicDBObject titleDocument = new BasicDBObject();
	            titleDocument.put("username", username);
	            titleDocument.put("title", title);
	            titleDocument.put("timestamp", new Date().getTime());

	            // Insert the title history record
	            titleHistoryCollection.insert(titleDocument);

	            HttpStatus status = HttpStatus.OK;
	            response.setStatus(status.value());
	        } else {
	            HttpStatus status = HttpStatus.BAD_REQUEST;
	            response.setStatus(status.value());
	            System.out.println("Username or Title not found in the respective collections");
	        }

	        // Close the MongoDB connection
	        mongoClient.close();

	    } catch (MongoException e) {
	        e.printStackTrace();
	    }finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}
	}

	/**
	 * The function retrieves users' history The function return array of pairs
	 * <title,viewtime> sorted by VIEWTIME in descending order
	 * 
	 * @param username
	 * @return
	 */
	@RequestMapping(value = "get_history_by_users", headers = "Accept=*/*", method = {
			RequestMethod.GET }, produces = "application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(HistoryPair.class)
	public HistoryPair[] getHistoryByUser(@RequestParam("entity") String username) {
		List<HistoryPair> historyPairs = new ArrayList<>();
		MongoClient mongoClient = null;

		try {
			// Connect to MongoDB
			mongoClient = new MongoClient("localhost", 27017);
			DB db = mongoClient.getDB("FinalProjBigData");

			// Access the "UserHistory" collection
			DBCollection userHistoryCollection = db.getCollection("UserHistory");

			// Create a query to find history records for the given user name
			BasicDBObject userQuery = new BasicDBObject();
			userQuery.put("username", username);

			// Sort the user history records by time stamp in descending order
			BasicDBObject userSort = new BasicDBObject();
			userSort.put("timestamp", -1);

			// Execute the query and get the cursor for the user history results
			DBCursor userCursor = userHistoryCollection.find(userQuery).sort(userSort);

			// Iterate over the cursor and populate the historyPairs list
			while (userCursor.hasNext()) {
				BasicDBObject userDocument = (BasicDBObject) userCursor.next();
				String title = userDocument.getString("title");
				Date viewTime = new Date(userDocument.getLong("timestamp"));
				
				HistoryPair historyPair = new HistoryPair(title, viewTime);
				historyPairs.add(historyPair);
			}

			// Close the cursor and the MongoDB connection
			userCursor.close();
			mongoClient.close();
		} catch (MongoException e) {
			e.printStackTrace();
			// If an exception occurs, return an empty array
			return new HistoryPair[0];
		}finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}

		// Sort the historyPairs list by view time in descending order
		Collections.sort(historyPairs, (hp1, hp2) -> hp2.getViewtime().compareTo(hp1.getViewtime()));

		// Convert the list to an array and return it
		return historyPairs.toArray(new HistoryPair[0]);
	}

	/**
	 * The function retrieves items' history The function return array of pairs
	 * <username,viewtime> sorted by VIEWTIME in descending order
	 * 
	 * @param title
	 * @return
	 */
	@RequestMapping(value = "get_history_by_items", headers = "Accept=*/*", method = {
			RequestMethod.GET }, produces = "application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(HistoryPair.class)
	public HistoryPair[] getHistoryByItems(@RequestParam("entity") String title) {
		List<HistoryPair> historyPairs = new ArrayList<>();
		MongoClient mongoClient = null;

		try {
			// Connect to MongoDB
			mongoClient = new MongoClient("localhost", 27017);
			DB db = mongoClient.getDB("FinalProjBigData");

			// Access the "TitleHistory" collection
			DBCollection titleHistoryCollection = db.getCollection("TitleHistory");

			// Create a query to find history records for the given title
			BasicDBObject titleQuery = new BasicDBObject();
			titleQuery.put("title", title);

			// Sort the title history records by time stamp in descending order
			BasicDBObject titleSort = new BasicDBObject();
			titleSort.put("timestamp", -1);

			// Execute the query and get the cursor for the title history results
			DBCursor titleCursor = titleHistoryCollection.find(titleQuery).sort(titleSort);

			// Iterate over the cursor and populate the title history pairs
			while (titleCursor.hasNext()) {
				BasicDBObject titleDocument = (BasicDBObject) titleCursor.next();
				String username = titleDocument.getString("username");
				Date viewTime = new Date(titleDocument.getLong("timestamp"));
				HistoryPair historyPair = new HistoryPair(username, viewTime);
				historyPairs.add(historyPair);
			}

			// Close the cursor and the MongoDB connection
			titleCursor.close();
			mongoClient.close();
		} catch (MongoException e) {
			e.printStackTrace();
		}finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}

		// Sort the history pairs by view time in descending order
		Collections.sort(historyPairs, (p1, p2) -> p2.getViewtime().compareTo(p1.getViewtime()));

		return historyPairs.toArray(new HistoryPair[0]);
	}

	/**
	 * The function retrieves all the users that have viewed the given item
	 * 
	 * @param title
	 * @return
	 */
	@RequestMapping(value = "get_users_by_item", headers = "Accept=*/*", method = {
			RequestMethod.GET }, produces = "application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(HistoryPair.class)
	public User[] getUsersByItem(@RequestParam("title") String title) {
		List<User> userList = new ArrayList<>();
		MongoClient mongoClient = null;

		try {
			// Connect to MongoDB
			mongoClient = new MongoClient("localhost", 27017);
			DB db = mongoClient.getDB("FinalProjBigData");

			// Access the "TitleHistory" collection
			DBCollection titleHistoryCollection = db.getCollection("TitleHistory");

			// Create a query to find history records for the given title
			BasicDBObject titleQuery = new BasicDBObject();
			titleQuery.put("title", title);

			// Execute the query and get the cursor for the title history results
			DBCursor titleCursor = titleHistoryCollection.find(titleQuery);

			// Iterate over the cursor and populate the user list
			while (titleCursor.hasNext()) {
				BasicDBObject titleDocument = (BasicDBObject) titleCursor.next();
				String username = titleDocument.getString("username");
				String password = titleDocument.getString("password");
				String firstName = titleDocument.getString("firstName");
				String lastName = titleDocument.getString("lastName");
				User user = new User(username, password, firstName, lastName);
				userList.add(user);
			}

			// Close the cursor and the MongoDB connection
			titleCursor.close();
			mongoClient.close();
		} catch (MongoException e) {
			e.printStackTrace();
		}finally {
            // Close the MongoDB connection
            if (mongoClient != null) {
                mongoClient.close();
            }
		}

		return userList.toArray(new User[0]);
	}

	/**
	 * The function calculates the similarity score using Jaccard similarity
	 * function: sim(i,j) = |U(i) intersection U(j)|/|U(i) union U(j)|, where U(i)
	 * is the set of usernames which exist in the history of the item i.
	 * 
	 * @param title1
	 * @param title2
	 * @return
	 */
	@RequestMapping(value = "get_items_similarity", headers = "Accept=*/*", method = {
			RequestMethod.GET }, produces = "application/json")
	@ResponseBody
	public double getItemsSimilarity(@RequestParam("title1") String title1, @RequestParam("title2") String title2) {
	    // Get the users who viewed each item
	    User[] users1 = getUsersByItem(title1);
	    User[] users2 = getUsersByItem(title2);

	    // Create sets of usernames for each item
	    Set<String> set1 = new HashSet<>();
	    Set<String> set2 = new HashSet<>();

	    for (User user : users1) {
	        set1.add(user.getUsername());
	    }

	    for (User user : users2) {
	        set2.add(user.getUsername());
	    }

	    // Calculate the Jaccard similarity score
	    Set<String> intersection = new HashSet<>(set1);
	    intersection.retainAll(set2);

	    Set<String> union = new HashSet<>(set1);
	    union.addAll(set2);

	    double similarity = (double) intersection.size() / union.size();

	    return similarity;
	}
}
